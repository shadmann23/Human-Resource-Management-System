
from flask import Flask
from .extensions import db, login_manager

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'hrms-secret'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///hrms.db'

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = "auth.login"

    from .auth.routes import auth_bp
    from .dashboard.routes import dashboard_bp
    from .employee.routes import employee_bp
    from .team.routes import team_bp
    from .leave.routes import leave_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(employee_bp)
    app.register_blueprint(team_bp)
    app.register_blueprint(leave_bp)

    with app.app_context():
        db.create_all()

    return app
