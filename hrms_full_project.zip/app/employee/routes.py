
from flask import Blueprint, render_template, request, redirect
from flask_login import login_required
from ..models import Employee
from ..extensions import db

employee_bp = Blueprint('employee', __name__, template_folder='../templates')

@employee_bp.route('/employees')
@login_required
def employees():
    employees = Employee.query.all()
    return render_template("employees.html", employees=employees)

@employee_bp.route('/employees/add', methods=['POST'])
@login_required
def add_employee():
    name = request.form['name']
    email = request.form['email']
    dept = request.form['department']

    emp = Employee(name=name,email=email,department=dept)
    db.session.add(emp)
    db.session.commit()

    return redirect("/employees")
