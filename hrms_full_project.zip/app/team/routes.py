
from flask import Blueprint, render_template, request, redirect
from flask_login import login_required
from ..models import Team
from ..extensions import db

team_bp = Blueprint('team', __name__, template_folder='../templates')

@team_bp.route('/teams')
@login_required
def teams():
    teams = Team.query.all()
    return render_template("teams.html", teams=teams)

@team_bp.route('/teams/add', methods=['POST'])
@login_required
def add_team():
    name = request.form['name']
    desc = request.form['description']
    team = Team(name=name, description=desc)
    db.session.add(team)
    db.session.commit()
    return redirect("/teams")
