
from flask import Blueprint, render_template, request, redirect
from flask_login import login_required
from ..models import LeaveRequest
from ..extensions import db

leave_bp = Blueprint('leave', __name__, template_folder='../templates')

@leave_bp.route('/leave')
@login_required
def leave():
    requests = LeaveRequest.query.all()
    return render_template("leave.html", requests=requests)

@leave_bp.route('/leave/apply', methods=['POST'])
@login_required
def apply_leave():
    name = request.form['name']
    reason = request.form['reason']

    req = LeaveRequest(employee_name=name, reason=reason)
    db.session.add(req)
    db.session.commit()

    return redirect("/leave")
